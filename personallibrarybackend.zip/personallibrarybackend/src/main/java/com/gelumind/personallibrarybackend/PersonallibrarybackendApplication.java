package com.gelumind.personallibrarybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonallibrarybackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonallibrarybackendApplication.class, args);
	}

}

package com.gelumind.personallibrarybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonallibrarybackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
